package com.stock;

public class StockAccount {
	String name;
	double balance;
}

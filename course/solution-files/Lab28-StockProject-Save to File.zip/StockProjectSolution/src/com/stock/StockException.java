package com.stock;

public class StockException extends Exception {

	private static final long serialVersionUID = 1L;

	public StockException() {
		// TODO Auto-generated constructor stub
	}

	public StockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StockException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public StockException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
